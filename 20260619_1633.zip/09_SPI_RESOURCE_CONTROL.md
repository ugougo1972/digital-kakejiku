# 09_SPI_RESOURCE_CONTROL.md

# digital-kakejiku SPIリソース制御仕様

最終更新: 2026-06-19

---

## 1. 目的

本書は、digital-kakejiku におけるSPI共有デバイスの排他制御を定義する。

対象は以下である。

- E-Paper
- microSD

---

## 2. 前提

E-PaperとmicroSDはSPI BUSを共有する。

共有対象は以下である。

- SCK
- MOSI
- MISO
- SPI BUS初期化状態

各デバイスは専用CSを持つ。

---

## 3. 設計方針

- 同時アクセス禁止
- SPI BUSは単一リソースとして管理
- CSの同時LOW禁止
- DISPLAY_UPDATE中のSTORAGE_WRITE禁止
- STORAGE_WRITE中のDISPLAY_UPDATE禁止
- 取得ログの欠損防止を優先
- 表示更新より保存処理を優先

---

## 4. ResourceManager

### 4.1 リソース名

```text
SPI_RESOURCE
```

### 4.2 状態

| 状態 | 意味 |
|---|---|
| FREE | 未使用 |
| LOCKED | 使用中 |
| ERROR | 異常状態 |

### 4.3 管理項目

| 項目 | 内容 |
|---|---|
| state | FREE/LOCKED/ERROR |
| owner | STORAGE_WRITE / DISPLAY_UPDATE |
| locked_at | lock取得時刻 |
| timeout_ms | lock timeout |
| last_error | 直近エラー |

---

## 5. 使用ルール

### 5.1 共通

SPI使用前に必ず `LOCK(SPI_RESOURCE)` を行う。

SPI使用後に必ず `UNLOCK(SPI_RESOURCE)` を行う。

例外発生時も `finally` 相当の処理で `UNLOCK` する。

### 5.2 STORAGE_WRITE

```text
LOCK(SPI_RESOURCE, owner=STORAGE_WRITE)
↓
microSD CS LOW
↓
write / flush
↓
microSD CS HIGH
↓
UNLOCK(SPI_RESOURCE)
```

### 5.3 DISPLAY_UPDATE

```text
LOCK(SPI_RESOURCE, owner=DISPLAY_UPDATE)
↓
E-Paper CS LOW
↓
draw / refresh
↓
E-Paper CS HIGH
↓
UNLOCK(SPI_RESOURCE)
```

---

## 6. 優先順位

| 優先 | 処理 | 理由 |
|---:|---|---|
| 1 | STORAGE_WRITE | ログ欠損防止 |
| 2 | ERROR_LOG_WRITE | 障害解析維持 |
| 3 | DISPLAY_UPDATE | 表示は再試行可能 |
| 4 | MAINTENANCE_READ | 保守操作 |

表示更新中に保存要求が発生した場合、表示更新を中断するかどうかは実装段階で判断する。初期実装では中断せず、次回保存タイミングで処理する。

---

## 7. timeout方針

| 処理 | timeout目安 |
|---|---:|
| STORAGE_WRITE | 1000ms |
| DISPLAY_UPDATE | 30000ms |
| MAINTENANCE_READ | 3000ms |

E-Paper更新は時間が長いため、DISPLAY_UPDATEのtimeoutは長めに設定する。

---

## 8. エラー処理

### 8.1 LOCK_TIMEOUT

発生時の処理。

```text
LOCK_TIMEOUT
↓
CS全HIGH確認
↓
SPI_RESOURCE state確認
↓
error_log記録
↓
可能ならSPI再初期化
↓
処理再試行または中止
```

### 8.2 CS異常

複数CSがLOWとなる状態は禁止する。

検出時は以下を行う。

- 全CSをHIGHへ戻す
- `error_log` へ記録
- SPI再初期化
- 該当処理を中止

---

## 9. ログ記録

SPI異常は `error_log` へ記録する。

| 項目 | 値 |
|---|---|
| module | storage または display |
| error_code | SPI-001 / SPI-002 / SPI-003 |
| severity | error |
| source | esp32 |

### error_code

| code | 内容 |
|---|---|
| SPI-001 | LOCK_TIMEOUT |
| SPI-002 | CS_CONFLICT |
| SPI-003 | SPI_INIT_FAILED |

---

## 10. GASとの関係

SPI_RESOURCEはESP32側のローカル制御である。

GAS側ではSPI状態を直接管理しない。

ただし、SPI異常は `error` PayloadとしてGASへ送信し、`error_log` に保存する。

---

## 11. 実装メモ

初期実装では単純な排他フラグでよい。

将来、FreeRTOSを本格使用する場合は以下を検討する。

- mutex
- semaphore
- queue
- display task / storage taskの分離

---

## 12. 将来拡張

- SPIデバイス追加対応
- mutex化
- FreeRTOS Semaphore対応
- SPI bus recovery
- 表示更新の遅延キュー
