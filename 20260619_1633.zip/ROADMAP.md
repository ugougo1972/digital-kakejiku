# ROADMAP.md

# digital-kakejiku Roadmap

最終更新: 2026-06-19

---

## 1. ロードマップ方針

本ロードマップは、過去のPoC成果を保持しつつ、2026-06-19時点の採択事項に合わせてGAS実装前の順序へ再整理する。

現在の最優先はハードウェア評価ではなく、GAS本実装およびSpreadsheet構成確定である。

---

## 2. フェーズ一覧

| Phase | 名称 | 状態 |
|---:|---|---|
| 0 | Repository / Documentation | 完了 |
| 1 | GAS通信PoC | 完了 |
| 1.5 | GAS Hardening / Stabilization | 完了 |
| 2 | ESP32 HTTPS POST / DeepSleep周期送信PoC | 完了 |
| 2.5 | 電源系UPS設計 | CONFIRMED |
| 3 | GAS基盤本実装 | 次作業 |
| 4 | Calendar Subsystem | GAS基盤後 |
| 5 | Poem Subsystem | Calendar後 |
| 6 | ESP32統合 | 後続 |
| 7 | 表示/UI統合 | 後続 |
| 8 | 長期運用 | 後続 |
| 9 | 筐体化 | 後続 |

---

## 3. Phase 0 : Repository / Documentation

### 目的

設計散逸防止。

### 実施内容

- GitHub Repository 初期化
- README.md 作成
- CURRENT_STATUS.md 作成
- ROADMAP.md 作成
- docs Tree 整備
- 01_HARDWARE_OVERVIEW.md 作成
- 05_WIRING_DIAGRAM.md 作成
- gas/src/Code.gs 配置

### 状態

完了。

---

## 4. Phase 1 : GAS通信PoC

### 目的

ESP32 ⇔ GAS ⇔ Spreadsheet 通信基盤確立。

### 実施内容

- GAS WebApp 作成
- doGet / doPost 実装
- 外部POST確認
- Spreadsheet append確認
- JSON保存確認
- PowerShellからのPOST確認

### 状態

完了。

---

## 5. Phase 1.5 : GAS Hardening / Stabilization

### 目的

ESP32実装前に、GAS受信側の安全性・検証性・保守性を高める。

### 実施内容

- secret validation
- device_id 必須化
- JSON validation
- number validation
- structured JSON response
- エラー応答整理
- Code.gs のGitHub保存
- PowerShell POSTとの整合確認

### 状態

完了。

### 注意

PoC段階では `API_SECRET` がコード中に存在し、`RawLogs` へraw JSONを保存していた。本実装では以下へ変更する。

- secretはScript Propertiesへ移行
- secretはSpreadsheetへ保存しない
- `RawLogs`は正式保存先としない

---

## 6. Phase 2 : ESP32 HTTPS POST / DeepSleep周期送信PoC

### 目的

実機ESP32からGAS WebAppへ観測データを送信し、DeepSleepを用いた周期送信の基礎を確認する。

### 実施内容

- Wi-Fi接続
- HTTPS POST
- JSON生成
- secret付与
- device_id付与
- GAS応答確認
- Spreadsheet記録確認
- 通信失敗時ログ出力
- DeepSleep設定
- timer wakeup
- boot_count保持
- wakeup_reason記録
- 起床後Wi-Fi再接続
- 起床後POST
- Spreadsheetへの周期保存確認

### 状態

PoC完了。

### 確認済み

```text
XIAO ESP32S3 Plus
↓ DeepSleep起床
Wi-Fi接続
↓
HTTPS POST
↓
GAS WebApp
↓
Spreadsheet RawLogs
↓
DeepSleep
```

約73分間、`boot_count` 1 から 66 までの継続記録を確認済み。

初回の `wakeup_reason` は `OTHER`、2回目以降は `TIMER` として記録済み。

### 注意点

据置型・通常USB給電・UPS運用を採択したため、通常運用ではDeepSleepを主軸にしない。DeepSleep PoCは、再起動耐性、通信経路、周期送信の検証成果として保持する。

---

## 7. Phase 2.5 : 電源系UPS設計

### 目的

据置型・常時USB給電を基本としつつ、USB給電喪失時に18650へ自動移行するUPS的電源構成を確立する。

### 採択済み構成

```text
USB-C入力
↓
PTC
↓
IP5306
├─ 18650
└─ 5V BUS
   ├─ SPS30
   └─ TPS63802
      ↓ 3.3V
      DMG2305UX-13
      ↓
      3.3V電源バス
      ↓
      XIAO ESP32S3 Plus / センサー群
```

### 採択内容

- 18650
- 18650電池ホルダー
- IP5306系モジュール
- TPS63802
- DMG2305UX-13
- PTC
- UPS的動作方針
- 手動切替なし
- TP4056単体案を主構成から除外

### 残タスク

- IP5306系モジュールの端子仕様確認
- USB給電中の通常動作確認
- USB抜去時の18650バックアップ動作確認
- USB復帰時の動作確認
- 長時間連続運転試験

### 状態

設計方針CONFIRMED。実機評価は後続。

---

## 8. Phase 3 : GAS基盤本実装

### 目的

PoCの `RawLogs` 単一保存から、本番用Spreadsheet構成へ移行する。

### 実施項目

- Spreadsheet構成確定
- `observation_log` 作成
- `event_log` 作成
- `error_log` 作成
- `system_log` 作成
- `source_config` 作成
- `solar_term_master` 作成
- `season_dictionary` 作成
- `calendar_master` 作成
- `poem_cache` 作成
- `doPost(e)` 本実装
- `type` 分岐
- Payload検証
- 必須項目検証
- 数値項目検証
- secret検証
- Script Properties移行
- secretログ出力禁止
- secret保存禁止
- JSON応答統一
- error_log記録
- PowerShell試験
- ESP32接続試験

### 完了条件

- `observation` Payloadが `observation_log` に保存される
- `event` Payloadが `event_log` に保存される
- `error` Payloadが `error_log` に保存される
- `system` Payloadが `system_log` に保存される
- 不正Payloadが保存されず、JSONエラー応答を返す
- 認証失敗時にsecretを保存・表示・ログ出力しない
- PowerShellから正常系・異常系を再現できる
- ESP32から正常系POSTが成立する

### 状態

次に着手する最優先フェーズ。

---

## 9. Phase 4 : Calendar Subsystem

### 目的

暦情報をGAS側で管理し、表示用カレンダーを生成する。

### 管理シート

- source_config
- solar_term_master
- season_dictionary
- calendar_master

### 情報源

| 情報 | 取得元 |
|---|---|
| 祝日 | 内閣府 |
| 二十四節気 | 国立天文台 |
| 七十二候名称 | 固定マスタ |
| 七十二候の読み・解説・キーワード | source_config管理URL |

### 実施項目

- `source_config` 列定義
- 祝日取得処理
- 二十四節気取得処理
- 七十二候固定マスタ整備
- 七十二候解説取得処理
- `calendar_master` 年次生成
- 取得失敗時の `error_log` 記録
- E-Paper表示用の「取得できません」状態生成
- 手動再生成処理
- 自動更新トリガ設計

### 禁止事項

- AIによる暦生成
- AIによる暦推定
- 前回値流用
- 欠損補完

### 完了条件

- 指定年の `calendar_master` を生成できる
- 取得失敗時に失敗状態を明示できる
- 失敗時に推測・補完しない
- E-Paper表示用データに「取得できません」を渡せる

---

## 10. Phase 5 : Poem Subsystem

### 目的

Gemini API Free Tier を使用し、「今日の詩」を1日1回生成して `poem_cache` に保存する。

### 実施項目

- Gemini API設定
- API KeyのScript Properties管理
- Promptテンプレート作成
- 入力データ抽出
- `calendar_master` 参照
- 観測データ参照
- 1日1回生成制御
- `poem_cache` 保存
- 表示時再生成禁止
- 失敗時の `error_log` 記録
- 失敗時の「取得できません」表示
- 最大リトライ制御

### 入力

- calendar_master
- observation_log
- system_log必要項目

### 出力

- poem_cache

### 禁止事項

- 暦情報生成
- 暦情報推定
- 欠損補完
- 失敗時の代替詩生成
- 表示アクセス時の都度生成

### 完了条件

- 1日1回のみ生成される
- 同日再表示では既存 `poem_cache` を使用する
- 生成失敗時に「取得できません」を返す
- Geminiが暦情報を補完しない設計になっている

---

## 11. Phase 6 : ESP32統合

### 目的

実測データをGAS本実装へ送信し、表示系・記録系と統合する。

### 対象

- SCD41
- SGP41
- SPS30
- BME680
- LTR390
- HLK-LD2410C
- ICS-43434
- RTC
- microSD
- Wi-Fi RSSI
- Battery / USB power

### 実施項目

- RTC連携
- SD連携
- センサー実測値取得
- JSON Payload生成
- `type=observation` 送信
- イベント送信
- エラー送信
- system送信
- retry方針整理
- redirect追従整理
- offline時キュー保存

### 完了条件

- 実測値POST
- Spreadsheet保存
- センサー未接続時の処理確認
- 通信失敗時にローカル保存
- 再送動作の方針確認

---

## 12. Phase 7 : 表示/UI統合

### 目的

前面E-Paperと背面OLEDを役割分担して統合する。

### 前面

- 7.5inch 800×480 E-Paper
- 表示専用
- 日めくり表示
- 暦情報
- 観測情報
- 今日の詩
- 取得失敗時は「取得できません」

### 背面

- OLED 128×96
- SSD1315優先
- 3ポジションダイヤル
- 設定
- 診断
- 保守

### SPI共有

E-PaperとmicroSDはSPI BUSを共有する。排他制御は `09_SPI_RESOURCE_CONTROL.md` に従う。

### 完了条件

- E-Paper初期表示
- 背面OLED初期表示
- 設定・診断・保守画面表示
- SPI競合なし
- 取得失敗時表示の確認

---

## 13. Phase 8 : 長期運用

### 目的

据置型観測器として長時間・長期間運用できる状態にする。

### 実施項目

- OTA検討
- キャッシュ
- オフライン運用
- リトライ制御
- 電源監視
- IP5306運用確認
- TPS63802 3.3V安定性確認
- DMG2305UX-13逆流防止確認
- 18650運用最適化
- バッテリー電圧監視
- 送信失敗時の再送方針
- Spreadsheet肥大化対策
- 月次ローテーション検討

### 完了条件

- 30日以上安定稼働
- 通信断復帰
- 停電復帰
- Spreadsheet肥大化の運用方針確定

---

## 14. Phase 9 : 筐体化

### 目的

据置型筐体へ実装し、実運用可能な物理構成へ移行する。

### 実施項目

- 据置型筐体
- 通気設計
- センサー配置
- ノブ固定
- E-Paper固定
- 背面OLED固定
- 放熱確認
- ケーブル整理
- 18650固定
- USB給電/充電経路整理
- IP5306 / TPS63802 / DMG2305UX-13実装部の固定

### 完了条件

- センサー値が筐体熱の影響で大きく破綻しない
- SPS30吸排気が確保される
- USB給電・停電・復電操作が安全に行える
- 前面表示と背面保守操作が干渉しない

---

## 15. 現在の最優先タスク

1. Spreadsheet構成確定
2. GAS本実装
3. Script Propertiesによるsecret管理
4. `type`別保存実装
5. Calendar Subsystem仕様確定
6. Poem Subsystem仕様確定
7. PowerShell試験
8. ESP32接続試験

---

## 16. 旧ロードマップからの変更点

| 旧記述 | 新整理 |
|---|---|
| UPS実機評価が最優先 | GAS本実装を最優先へ変更 |
| `RawLogs` schema固定 | `RawLogs`はPoC用。正式保存先は分割シート |
| `GeminiLogs` | `poem_cache`へ整理 |
| `ContextLogs` | `calendar_master`、`poem_cache`、system/errorへ責務分離 |
| RGBロータリーエンコーダ | RGB無し水平ダイヤル式へ整理 |
| RTC型番未確定 | DS3231+AT24C32+CR2032へ統一 |
