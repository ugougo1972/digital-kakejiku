# 11_SECURITY_MANAGEMENT.md

# digital-kakejiku セキュリティ管理仕様

最終更新: 2026-06-19

---

## 1. 目的

本書は、digital-kakejiku における認証情報、API Key、device_id、ログ出力禁止情報の管理方針を定義する。

---

## 2. 対象

| 対象 | 内容 |
|---|---|
| secret | ESP32→GAS認証用共有シークレット |
| device_id | 端末識別子 |
| GEMINI_API_KEY | Gemini API用Key |
| Wi-Fi情報 | SSID、password |
| access_token | 将来拡張用token |
| Spreadsheet ID | GAS側参照先ID |

---

## 3. 基本方針

- secretをコードへ直書きしない。
- secretをSpreadsheetへ保存しない。
- secretをログ出力しない。
- API KeyをSpreadsheetへ保存しない。
- API Keyをログ出力しない。
- raw_json保存時は機密値を除去またはマスクする。
- HTTPS通信を必須とする。
- 初号機では共有secret方式を採用する。
- 将来HMACまたはDevice Registryを検討する。

---

## 4. GAS側管理

### 4.1 保存先

GAS側の機密値はScript Propertiesに保存する。

| Key | 内容 |
|---|---|
| API_SECRET | ESP32認証用secret |
| GEMINI_API_KEY | Gemini API Key |
| SPREADSHEET_ID | Spreadsheet ID |

### 4.2 禁止事項

- `const API_SECRET = "..."` のような直書き
- `Logger.log(secret)` のようなログ出力
- Spreadsheetへのsecret保存
- error_logへのsecret保存
- raw_jsonへのsecret保存

---

## 5. ESP32側管理

### 5.1 保存先

ESP32側のsecretはNVSに保存する方針とする。

初期開発中は暫定的にソース内定義を許容する場合があるが、GitHubへ実secretをcommitしてはならない。

### 5.2 禁止事項

- 実secretのGitHub commit
- Wi-Fi passwordのGitHub commit
- API KeyのGitHub commit
- Serial出力へのsecret表示

---

## 6. Spreadsheet管理

Spreadsheetへ保存してよいもの。

- device_id
- 観測データ
- イベント
- エラーコード
- 機密除去済みraw_json
- Calendar Subsystemの取得結果
- Poem Subsystemの生成結果

Spreadsheetへ保存してはいけないもの。

- secret
- GEMINI_API_KEY
- Wi-Fi password
- access_token
- 認証ヘッダー全文

---

## 7. device_id

### 7.1 形式

```text
dk-xxxx
```

例。

```text
dk-0001
```

### 7.2 方針

- device_idは端末識別子であり、秘密情報ではない。
- ただし、外部公開ログで不要に露出させない。
- 将来、Device Registryを導入する場合はdevice_id単位で有効/無効を管理する。

---

## 8. secretローテーション

### 8.1 初号機

初号機では手動ローテーションとする。

手順。

1. 新secretを生成
2. GAS Script Propertiesを更新
3. ESP32 NVSを更新
4. PowerShellで接続試験
5. ESP32で接続試験
6. 旧secretを破棄

### 8.2 将来拡張

- Secret Rotation API
- Device Registry
- Device Revoke
- HMAC署名

---

## 9. ログ出力禁止項目

以下をログ出力してはならない。

- secret
- GEMINI_API_KEY
- access_token
- Wi-Fi password
- Authorization header
- 認証失敗時に受信したsecret値

---

## 10. raw_jsonマスク仕様

raw_json保存前に以下を除去またはマスクする。

| 項目 | 処理 |
|---|---|
| secret | 削除 |
| access_token | 削除 |
| api_key | 削除 |
| password | 削除 |
| authorization | 削除 |
| wifi_password | 削除 |

推奨処理。

```text
sanitizePayload(payload)
↓
removeSensitiveFields
↓
JSON.stringify
↓
Spreadsheet保存
```

---

## 11. 認証失敗時の扱い

認証失敗時は以下とする。

- `status=error`
- `code=401`
- `error_code=AUTH-001`
- secret値は応答に含めない
- secret値はログに含めない
- error_logへは機密除去済み情報のみ保存する

---

## 12. Gemini API Key管理

Gemini API KeyはScript Propertiesに保存する。

Poem Subsystem以外では使用しない。

Calendar SubsystemではGemini APIを使用しない。

---

## 13. GitHub運用ルール

commit禁止。

- 実secret
- Gemini API Key
- Wi-Fi password
- Spreadsheetの非公開情報
- `.env` 実ファイル
- 認証済みトークン

commit可能。

- `.env.example`
- `config.example.json`
- ダミーsecret
- ダミーdevice_id
- 仕様書

---

## 14. GAS実装前チェックリスト

- [ ] `API_SECRET` をScript Propertiesへ移行
- [ ] `GEMINI_API_KEY` をScript Propertiesへ登録
- [ ] 実secretをCode.gsから削除
- [ ] raw_json保存前のsanitize処理を実装
- [ ] 認証失敗時にsecretを出力しない
- [ ] Spreadsheetへsecretが保存されないことを確認
- [ ] PowerShell異常系試験を行う
- [ ] ESP32接続試験を行う

---

## 15. 将来拡張

- Device Registry
- Secret Rotation API
- Device Revoke
- HMAC署名
- device_id別権限管理
- 操作ログ監査
